#!/usr/bin/env python3
"""brain-games."""
from brain_games.games_logic import welcome_user


def main():
    """Welcom fun."""
    welcome_user()


if __name__ == '__main__':
    main()
